-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sqa
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblcar`
--

DROP TABLE IF EXISTS `tblcar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `licensePlate` varchar(255) NOT NULL,
  `seatNumber` int NOT NULL,
  `price` float NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `categoryId` int NOT NULL,
  `branchId` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `licensePlate` (`licensePlate`),
  KEY `branchId` (`branchId`),
  KEY `categoryId` (`categoryId`),
  CONSTRAINT `tblcar_ibfk_1` FOREIGN KEY (`branchId`) REFERENCES `tblbranch` (`id`),
  CONSTRAINT `tblcar_ibfk_2` FOREIGN KEY (`categoryId`) REFERENCES `tblcarcategory` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcar`
--

LOCK TABLES `tblcar` WRITE;
/*!40000 ALTER TABLE `tblcar` DISABLE KEYS */;
INSERT INTO `tblcar` VALUES (1,'VINFAST LUX  A2.0','Brahminy White','30A-686.86',4,600000,'https://shop.vinfastauto.com/on/demandware.static/-/Sites-app_vinfast_vn-Library/default/dw218d05cc/images/Lux-A/hinh-anh-gia-VinFast-Lux-a2.0-price-mau-trang-brahminy-white.png','A',3,5),(2,'Honda City','Red','30A-555.55',4,500000,'https://i.xeoto.com.vn/auto/honda/city/honda-city-2021.png','A',2,4),(3,'Toyota Camry','White','30A-666.66',5,700000,'https://cdn1.otosaigon.com/data-resize/carinfo/20210727/EZ03OyWCbnG8t4d1Su88pZKOZpOgoSpXiFRu3uxP.jpg?w=838','A',4,3),(4,'Toyota Fortuner','White','30A-777.77',7,900000,'https://i.xeoto.com.vn/auto/w600/toyota/fortuner/toyota-fortuner-2020-52327.png','A',4,3),(5,'VINFAST FADIL','Luxury Blue','30A-444.44',5,500000,'https://shop.vinfastauto.com/on/demandware.static/-/Sites-vinfast_vn_master/default/dw02ef2e69/images/FADIL/SMA/CE18.png','A',1,5);
/*!40000 ALTER TABLE `tblcar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-04 21:14:37
